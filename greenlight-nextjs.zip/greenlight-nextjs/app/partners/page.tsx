import { supabase } from "@/lib/supabase";
import PageShell from "@/components/PageShell";

export const metadata = { title: "Partners | Greenlight · Mesa, AZ" };

export default async function Partners() {
  const { data: page } = await supabase.from("page_content").select("*").eq("slug","partners").single();
  return <PageShell page={page} />;
}
